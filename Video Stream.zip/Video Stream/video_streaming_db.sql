-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2023 at 04:41 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `video_streaming_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `author_tbl`
--

CREATE TABLE `author_tbl` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `movie_name` varchar(255) DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `date_publish` date DEFAULT NULL,
  `actors` varchar(255) DEFAULT NULL,
  `description` varchar(25000) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `image_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `author_tbl`
--

INSERT INTO `author_tbl` (`id`, `firstname`, `lastname`, `gender`, `movie_name`, `genre`, `date_publish`, `actors`, `description`, `link`, `image_url`) VALUES
(3, 'Johna Grace', 'Doctora', 'Female', 'Demon Slayer', 'action', '2023-05-04', 'Tanjiro, Nezuko, Zenitsu, Inosuke\r\n                    ', 'Slaying demons...', NULL, 'IMG-6474b3633e4f86.82035567.jpg'),
(4, 'Marco Jerome', 'Gador', 'Male', 'Attack on Titan', 'horror', '2023-05-25', 'Eren Yeager, Levi ackerman, Mikasa Ackerman\r\n                    ', 'killing titan\r\n                    ', NULL, 'IMG-6474b4973a5e01.47396500.jpg'),
(5, 'Gege ', 'Akutami', 'Male', 'Jujutsu Kaisen', 'action', '2023-06-03', 'Gojo Satoru, Fushiguro Megumi, kugisaki Nobara, Itadori Yuji\r\n                    ', 'Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis a', NULL, 'IMG-647b47fd94ae86.46982950.jpg'),
(8, 'Makoto', 'Shinkaii', 'Male', 'Your Name', 'action', '2023-06-04', 'qweqweqw                                        ', 'qweqweqweqweqweqweqw                                        ', NULL, 'IMG-647c9c47b0f5b6.67582847.jpg'),
(9, 'qwe', 'qweqwe', 'Male', 'Bleach', 'action', '2023-06-07', 'qeqweqw', 'qweqweqweqw\r\n                    ', NULL, 'IMG-647d3e3972c600.44801845.jpg'),
(10, 'qweqwe', 'qweqweqw', 'Male', 'Naruto', 'action', '2023-06-05', 'qweqwe\r\n                    ', 'qweqweqw\r\n                    ', NULL, 'IMG-647d42d4a5c9d0.85049923.jpg'),
(11, 'qweqw', 'qweqw', 'Male', 'One Piece', 'action', '2023-06-05', 'qwewqe\r\n                    ', 'qweqwewq\r\n                    ', NULL, 'IMG-647d4ef5d33d95.80655154.jpg'),
(12, 'qwe', 'qweqweqw', 'Male', 'Akame ga Kill', 'horror', '2023-06-05', 'qweqwe\r\n                    ', 'qweqwe\r\n                    ', NULL, 'IMG-647d56e702cc15.04601362.jpg'),
(13, 'qweqw', 'qwewqe', 'Male', 'Blue Lock', 'action', '2023-06-06', 'qweqweqw\r\n                    ', 'qweqwewqewq\r\n                    ', NULL, 'IMG-647d57496cdb98.10997350.jpg'),
(14, 'qweqwe', 'qweqwewq', 'Male', 'Spy x Family', 'action', '2023-06-05', 'qweqwe\r\n                                        ', 'qweqweqw\r\n                                        ', NULL, 'IMG-647d57714f2985.15486281.jpg'),
(15, 'qwe', 'qweqwe', 'Male', 'VinLand Saga', 'action', '2023-06-09', 'qweqw\r\n                    ', 'Young Thorfinn grew up listening to the stories of old sailors that had traveled the ocean and reached the place of legend, Vinland. It\'s said to be warm and fertile, a place where there would be no need for fighting—not at all like the frozen village in Iceland where he was born, and certainly not like his current life as a mercenary. War is his home now. Though his father once told him, \"You have no enemies, nobody does. There is nobody who it\'s okay to hurt,\" as he grew, Thorfinn knew that nothing was further from the truth.\n                    ', 'https://www.youtube.com/watch?v=CCXLUQzuigw', 'IMG-64832f9039f0d0.03827875.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `image_url`) VALUES
(8, 'IMG-5f8954bd209a92.78214246.jpg'),
(9, 'IMG-5f8954caa02539.76436861.jpg'),
(10, 'IMG-6474ac06ba0c93.73828726.png'),
(11, 'IMG-6474b00e300910.87830122.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `access` varchar(255) DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`id`, `firstname`, `lastname`, `gender`, `age`, `dob`, `username`, `password`, `access`) VALUES
(1, 'Johna Grace', 'Doctora', 'Male', '21', '2002-07-16', 'admin1', 'admin1', 'admin'),
(3, 'John Jacob', 'Dimaya', 'Male', '19', '2003-09-18', 'admin2', 'admin2', 'admin'),
(4, 'Marco Jerome', 'Gador', 'Male', '23', '2013-05-01', 'marco123', 'marco123', 'admin'),
(5, 'Ana Bien', 'Salazar', 'Male', '21', '2023-06-26', 'bien123', 'bien123', 'user'),
(6, 'Baby J', 'Baby JJ', 'Male', '19', '2023-06-10', 'babyj123', 'd70f4206fea572c9d2fc7e35ec3838c3', 'admin'),
(7, 'Clifford Laureles', 'Lorenzo', 'Male', '21', '2023-06-28', 'cliff123', '81f7bd7b83ba4611c64f4f04e499467f', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `author_tbl`
--
ALTER TABLE `author_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_tbl`
--
ALTER TABLE `user_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `author_tbl`
--
ALTER TABLE `author_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_tbl`
--
ALTER TABLE `user_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
