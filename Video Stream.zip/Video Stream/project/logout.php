<?php
require_once('php/init.php');
logout();

header("Location: login.php");

?>